package com.nashtech.assetmanagement.steps.modals;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.nashtech.assetmanagement.utils.JsonUtil;
import java.io.FileNotFoundException;

public class StudentData {
    private String id;
    private String name;
    private String email;
    private String gender;
    private String status;

    /** ---------------------- Constructor ------------------------ */
    public StudentData() {}

    public StudentData(String nameOfJsonFile) throws FileNotFoundException {
        StudentData studentData = covertJsonToObject(nameOfJsonFile);
        this.id = StudentData.id;
        this.name = StudentData.name;
        this.email = StudentData.email;
        this.gender = StudentData.gender;
        this.status = StudentData.status;
    }

    /** ---------------------- Methods ------------------------ */
    private StudentData covertJsonToObject(String nameOfJsonFile) throws FileNotFoundException {
        JsonUtil1 jsonUtil = new JsonUtil1();
        JsonReader reader = jsonUtil.readJsonFile(nameOfJsonFile);
        Gson gson = new Gson();
        StudentData studentData = gson.fromJson(reader, StudentData.class);
        return studentData;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getGender() {
        return gender;
    }

    public String getStatus() {
        return status;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}