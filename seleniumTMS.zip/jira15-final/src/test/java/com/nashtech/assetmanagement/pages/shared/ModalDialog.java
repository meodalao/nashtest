package com.nashtech.assetmanagement.pages.shared;
import com.nashtech.assetmanagement.pages.BasePage;

import static  com.nashtech.assetmanagement.steps.StepHooks.driver;

public class ModalDialog extends BasePage {

    public void dismiss() {
        waitForAlertToBePresent();
        driver.switchTo().alert().dismiss();
    }

    public void accept() {
        waitForAlertToBePresent();
        driver.switchTo().alert().accept();
    }

    public String getText() {
        waitForAlertToBePresent();
        return driver.switchTo().alert().getText();
    }

    public void sendKeys(String text) {
        waitForAlertToBePresent();
        driver.switchTo().alert().sendKeys(text);
    }
}