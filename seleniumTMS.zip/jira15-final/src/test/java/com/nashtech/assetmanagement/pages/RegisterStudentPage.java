package com.nashtech.assetmanagement.pages;

import org.openqa.selenium.WebElement;
import com.nashtech.assetmanagement.driver.Browser;
import org.openqa.selenium.WebDriverException;

public class RegisterStudentPage extends BasePage{

    public void inputName(String firstName) {inputText(TXT_FIRSTNAME, firstName);}

    public void inputLastDemo(String LastDemo) {inputText(TXT_LASTNAMEDEMO, LastDemo);}

    public void inputEmail(String Email) {
        inputText(TXT_EMAILDEMO, Email);
    }

    public void inputMobileNumber(String MobileNumber) {inputText(TXT_MOBILEDEMO, MobileNumber);}

    public void clickGenderRDO() {
        ClickElement(RDO_GENDERDEMO);
    }

    public void inputProjectMobileDemo (String mobilePhone){
        inputText(TXT_MOBILEDEMO, mobilePhone);
    }

    public void clickSelectProjectDOBBtn() {
        ClickElement(TXT_DOB);
    }

    public void inputProjectDOB(String DOB) {
        inputText(INP_DOB, DOB);
    }

    public void inputSubjectsDemo (String Subjects){
        inputText(TXT_SUBJECTS, Subjects);
    }

    public void clickSelectHobbiesProjectCheckbox() {
        ClickElement(CHK_HOBBIES);
    }

    public void inputCurrentAddressDemo (String CurrentAddress){
        inputText(TXT_CURRENTADDRESS, CurrentAddress);
    }

    public void clickSelectStateProjectBtn() {
        ClickElement(DDL_STATE);
    }

    public void inputStateProjectBtn2() {
        ClickElement(INP_STATE);
    }

    public void clickSelectSectorProjectBtn() {
        ClickElement(DDL_STATE);
    }

    public void inputCityProjectBtn() {ClickElement(DDL_CITY);}

    public void inputCityProjectBtn2() {ClickElement(INP_CITY);}

    public void clickCreateSubmitProjectBtn() {
        ClickElement(BTN_SUBMIT);
    }
    public static void navigate(String url) {
//        LOGGER.info("Navigate to page {} ",  url);
        do try {
            Browser.getDriver().get(System.getProperty("BASE_URL") + url);
            break;
        } catch (WebDriverException ignored) {
//            LOGGER.warn("WebDriverException");
        }
        while (true);
    }
}
