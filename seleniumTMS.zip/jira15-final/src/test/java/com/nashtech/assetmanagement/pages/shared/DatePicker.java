//package com.nashtech.assetmanagement.pages.shared;
//import org.openqa.selenium.By;
//
//import com.nashtech.assetmanagement.pages.BasePage;
//import java.time.LocalDate;
//import java.time.YearMonth;
//import java.time.format.DateTimeFormatter;
//
//public class DatePicker extends BasePage {
//    private static final By BTN_PREVIOUS_MONTH = By.cssSelector("button[class*=uib-left]");
//    private static final By BTN_NEXT_MONTH = By.cssSelector("button[class*=uib-right]");
//    private static final By LBL_CURRENT_MONTH = By.cssSelector("button[class*=uib-title]>strong");
//    private static final String LBL_DAY = "//span[not(contains(@class, 'text-muted')) and text()='%s']/parent::button";
//    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern(System.getProperty("DATE_FORMAT"));
//    public void clickPreviousMonthBtn() {
//        clickElement(BTN_PREVIOUS_MONTH);
//    }
//    public void clickNextMonthBtn() {
//        clickElement(BTN_NEXT_MONTH);
//    }
//
//    public YearMonth getCurrentMonthInCalender() {
//        String[] parts = getText(LBL_CURRENT_MONTH).split(" ");
//        String currentMonth = parts[0];
//        String currentYear = parts[1];
//
//        while (currentMonth.length() > 3) currentMonth = currentMonth.substring(0, currentMonth.length() - 1);
//
//        return YearMonth.from(LocalDate.parse("01" + "-" + currentMonth + "-" + currentYear, dtf));
//    }
//    public void selectDateInCalender(String date) {
//        YearMonth currentMonth = getCurrentMonthInCalender();
//        YearMonth inputMonth = YearMonth.from(LocalDate.parse(date, dtf));
//
//        while (!currentMonth.equals(inputMonth)) {
//            if (currentMonth.compareTo(inputMonth) > 0) {
//                clickPreviousMonthBtn();
//            }
//            else {
//                clickNextMonthBtn();
//            }
//            currentMonth = getCurrentMonthInCalender();
//        }
//
//        String day = String.valueOf(LocalDate.parse(date, dtf).getDayOfMonth());
//        if (day.length() == 1) day = "0" + day;
//
//        clickElement(By.xpath(String.format(LBL_DAY, day)));
//    }
//}
//
