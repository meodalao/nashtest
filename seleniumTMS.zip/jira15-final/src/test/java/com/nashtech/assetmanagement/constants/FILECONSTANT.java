package com.nashtech.assetmanagement.constants;

public class FILECONSTANT {
    public static final String PROJECT_DATA = "/project.json";
}
