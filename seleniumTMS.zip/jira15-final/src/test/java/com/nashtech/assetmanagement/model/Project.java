package com.nashtech.assetmanagement.model;
import com.google.gson.JsonObject;

public class Project {
        public String TXT_NAMEDEMO;
        public String TXT_LASTNAMEDEMO;
        public String TXT_EMAILDEMO;
        public String TXT_MOBILEDEMO;
        public String TXT_SUBJECTS;
        public String TXT_CURRENTADDRESS;

        public String projectManager;
        public String deliveryProgramManager;
        public String engagementManager;
        public String shortDescription;
        public String longDescription;
        public String technologies;
        public String clientName;
        public String clientDescription;
        public String clientIndustrySector;


    }


