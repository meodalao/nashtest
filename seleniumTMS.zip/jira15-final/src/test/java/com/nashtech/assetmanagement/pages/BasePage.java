package com.nashtech.assetmanagement.pages;

import com.nashtech.assetmanagement.steps.StepHooks;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.time.Duration;

public class BasePage {
    public WebDriverWait wait = new WebDriverWait(StepHooks.driver, Duration.ofSeconds(Long.parseLong(System.getProperty("TIMEOUT_IN_SECOND"))));


    public void navigate(String url) {
        StepHooks.driver.get(System.getProperty("BASE_URL") + url);
    }

    public WebElement waitForElementToBeClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public WebElement waitForElementToBeVisible(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public void waitForAlertToBePresence() {
        wait.until(ExpectedConditions.alertIsPresent());
    }

    public Alert switchDriverToAlert() {
        waitForAlertToBePresence();
        return StepHooks.driver.switchTo().alert();
    }

    public boolean isDisplayed(By locator) {
        try {
            waitForElementToBeVisible(locator);
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    public boolean isElementContainClass(By locator, String klass) {
        WebElement element = waitForElementToBeVisible(locator);
        return element.getAttribute("class").contains(klass);
    }

    public void inputText(By locator, String text) {
        WebElement element = waitForElementToBeClickable(locator);
        element.sendKeys(text);
    }

    public void clickElement(By locator) {
        WebElement element = waitForElementToBeClickable(locator);
        element.click();
    }

    public void selectElementInDropdownList(By ddlLocator, By optionLocator) {
        clickElement(ddlLocator);
        clickElement(optionLocator);
    }

    public String getText(By locator) {
        WebElement element = waitForElementToBeVisible(locator);
        return element.getText();
    }

//    public void Robot() throws AWTException {
//        public void typeKey ( int keyCode){
//            keyPress(keyCode);
//            delay(20);
//            keyRelease(keyCode);
//        }
//    }

//    public static void selectDate() throws AWTException {
//        try {
//            Robot robot = new Robot();
//            for (int i = 0; i <= 4; i++) {
//                robot.keyPress(KeyEvent.VK_CONTROL);
//                robot.typeKey(KeyEvent.VK_A);
//                robot.keyRelease(KeyEvent.VK_SUBTRACT);
//                robot.keyPress(KeyEvent.VK_CONTROL);
//            }
//        } catch (Exception ex) { // Either AWTException or SecurityException
//            System.out.println("Oh no!");
//        }
//    }

    public void SignInSuccessfully() throws AWTException {
        Robot robot = new Robot();
        for (int i = 0; i <= 4; i++) {
            robot.keyPress(KeyEvent.VK_CONTROL);
        }
    }
}