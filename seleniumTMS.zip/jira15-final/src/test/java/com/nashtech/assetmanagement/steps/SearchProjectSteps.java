package com.nashtech.assetmanagement.steps;

import com.nashtech.assetmanagement.CONTEXT.ScenarioContext;
import com.nashtech.assetmanagement.model.Project;
import com.nashtech.assetmanagement.pages.SearchProjectPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class SearchProjectSteps {
    SearchProjectPage searchProjectPage = new SearchProjectPage();
    ScenarioContext scenarioContext;

    public SearchProjectSteps(ScenarioContext context) {
        scenarioContext = context;
    }

    @When("the user applies some search criteria \\({string}\\/{string}\\/{string})")
    public void theUserAppliesSomeSearchCriteriaNameLocationType(String projectName, String location, String projectType) {
        scenarioContext.setContext("searchCriteria", new Project(projectName, projectType, location));
        if(!projectName.equals("")) searchProjectPage.inputBookName(projectName);
    }

    @When("the user clicks on Search button")
    public void theUserClicksOnSearchButton() {
        searchProjectPage.clickSearchBtn();
    }

    @Then("all projects matched with input criteria will be displayed")
    public void allProjectsMatchedWithInputCriteriaWillBeDisplayed() {
        List<Project> projectList = searchProjectPage.getResultProjectListInAllPages();
        Project searchCriteria = scenarioContext.getContext("searchCriteria", Project.class);

        for (Project project : projectList) {
            assertThat("Verify project name", project.projectName, containsStringIgnoringCase(searchCriteria.projectName));
            if(searchCriteria.location != "") {
                assertThat("Verify location", project.location, equalTo(searchCriteria.location));
            }
            if(searchCriteria.projectType != "") {
                assertThat("Verify project type", project.projectType, equalTo(searchCriteria.projectType));
            }
        }
    }

}