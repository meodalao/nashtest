package com.nashtech.assetmanagement.constants;

public class APIConstants {

    public enum RequestType {
        POST,
        PUT,
        PATCH,
        DELETE,
        GET
    }

    public static final String HOST = "https://gorest.co.in";
    public static final String TOKEN = "2694b121725c7aa5621056355b10453fa4d2a8118e8a6cc347c9b547a5beeb3d";

    //User APIs
    public static final String USER_PREFIX = "/public-api/users";
    public static final String GET_USERS_ENDPOINT = "?page=%s";
    public static final String USER_ID_ENDPOINT = "/%s";
}