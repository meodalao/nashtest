package com.nashtech.assetmanagement.steps;
import com.nashtech.assetmanagement.constants.UrlConstants;
import com.nashtech.assetmanagement.CONTEXT.ScenarioContext;
import com.nashtech.assetmanagement.pages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class LoginSteps {
    LoginPage loginPage = new LoginPage();
    ScenarioContext scenarioContext;

    public LoginSteps(ScenarioContext context) {scenarioContext = context;}

    @Given("the user is in Login Page")
    public void theUserIsInLoginPage() {
        loginPage.navigate(UrlConstants.LOGIN_URL);
    }

    @When("the user input {string} into Username textbox")
    public void theUserInputIntoUsernameTextbox(String username) {
        loginPage.inputUsername(username);
        scenarioContext.setContext("username", username);
    }

    @When("the user input {string} into Password textbox")
    public void theUserInputIntoPasswordTextbox(String password) {
        loginPage.inputPassword(password);
    }

    @When("the user click Login button")
    public void theUserClickLoginButton() {
        loginPage.clickLoginBtn();
    }

    @Then("the error message is shown under Username field")
    public void theErrorMessageIsShownUnderUsernameField() {
        assertThat("Verify username", loginPage.getUsernameErrorMessage(), equalTo("This is a required field."));
    }

    @Then("the error message is shown under Password field")
    public void theErrorMessageIsShownUnderPasswordField() {
        assertThat("Verify username", loginPage.getPasswordErrorMessage(), equalTo("This is a required field."));
    }

    @Then("the invalid account error message is shown")
    public void theInvalidAccountErrorMessageIsShown() {
        assertThat("Verify username", loginPage.getInvalidAccountErrorMessage(), equalTo("The Username or Password you entered is incorrect"));
    }

    @Given("the user is log into the TMS website")
    public void theUserIsLogIntoTheTMSWebsite() {
        loginPage.loginWithDefaultAccount();
    }
}