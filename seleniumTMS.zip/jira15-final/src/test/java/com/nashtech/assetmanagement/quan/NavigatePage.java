package com.nashtech.demoqa.pages.shared;

import com.nashtech.demoqa.pages.BasePage;

public class NavigatePage extends BasePage {

}
