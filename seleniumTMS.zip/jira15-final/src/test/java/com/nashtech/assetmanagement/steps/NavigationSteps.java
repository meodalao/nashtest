package com.nashtech.assetmanagement.steps;

import com.nashtech.assetmanagement.CONTEXT.ScenarioContext;
import com.nashtech.assetmanagement.pages.NavigationPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class NavigationSteps {
    NavigationPage navigationPage = new NavigationPage();
    ScenarioContext scenarioContext;

    public NavigationSteps(ScenarioContext context) {
        scenarioContext = context;
    }

    @Then("the Username is shown correctly")
    public void theUsernameIsShownCorrectly() {
        String username = scenarioContext.getContext("username", String.class);
        assertThat("Verify username", navigationPage.getUsername(), equalTo(username));
    }
    @Given("the user navigate to BookStore page")
    public void theUserNavigateToCreateFormPage() {
        navigationPage.clickSearchProjectLbl();
    }

    @Given("the user navigate to profile page")
    public void theUserIsInLoginPage() {
        navigationPage.clickCreateProjectLbl();
    }

    @Given("the user navigate to BookStore page")
    public void theUserNavigateToSearchProjectPage() {
        navigationPage.clickSearchProjectLbl();
    }
}