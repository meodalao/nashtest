package com.nashtech.assetmanagement.pages;

import org.openqa.selenium.By;

public class LoginPage extends BasePage {
    private static final By TXT_USERNAME = By.id("username");
    private static final By TXT_PASSWORD = By.id("password");
    private static final By BTN_LOGIN = By.cssSelector("input[value=Login]");
    private static final By LBL_BLANK_USERNAME_MESSAGE = By.cssSelector("div[ng-messages*='loginForm.username.$error'] > p");
    private static final By LBL_BLANK_PASSWORD_MESSAGE = By.cssSelector("div[ng-messages*='loginForm.password.$error'] > p");
    private static final By LBL_INVALID_ACCOUNT_MESSAGE = By.cssSelector("div[ng-show=isError]");

    public void inputUsername(String userName) {inputText(TXT_USERNAME, userName);}
    public void inputPassword(String password) {
        inputText(TXT_PASSWORD, password);
    }
    public void clickLoginBtn() {
        clickElement(BTN_LOGIN);
    }
    public String getUsernameErrorMessage() {
        return getText(LBL_BLANK_USERNAME_MESSAGE);
    }
    public String getPasswordErrorMessage() {
        return getText(LBL_BLANK_PASSWORD_MESSAGE);
    }
    public String getInvalidAccountErrorMessage() {
        return getText(LBL_INVALID_ACCOUNT_MESSAGE);
    }

    public void loginWithDefaultAccount() {
        inputUsername(System.getProperty("DEFAULT_USERNAME"));
        inputPassword(System.getProperty("DEFAULT_PASSWORD"));
        clickLoginBtn();
    }
}

