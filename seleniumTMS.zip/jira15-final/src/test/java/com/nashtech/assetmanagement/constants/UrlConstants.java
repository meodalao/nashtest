package com.nashtech.assetmanagement.constants;

public class UrlConstants {
    public static final String BASE_URL = "/login";
    public static final String LOGIN_URL= "/login";
    public static final String USER_URL= "/profile";
    public static final String ADD_BOOK_URL= "books";


}
