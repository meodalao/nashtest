//package com.nashtech.assetmanagement.steps;
//
//import com.nashtech.assetmanagement.constants.FILECONSTANT;
//import com.nashtech.assetmanagement.CONTEXT.ScenarioContext;
//import com.nashtech.assetmanagement.model.Project;
//import com.nashtech.assetmanagement.pages.*;
////import com.nashtech.assetmanagement.pages.shared.DatePicker;
//import com.nashtech.assetmanagement.pages.shared.ModalDialog;
//import com.nashtech.assetmanagement.utils.JsonUtil;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.When;
//
//import java.io.IOException;
//
//public class CreateProjectSteps {
//    NavigationPage navigationPage = new NavigationPage();
//    CreateStudentPage createProjectPage = new CreateStudentPage();
////    DatePicker datePicker = new DatePicker();
//    BookStorePage projectInformationPage = new BookStorePage();
//    ModalDialog modalDialog = new ModalDialog();
//    Project project;
//    ScenarioContext scenarioContext;
//
//    public CreateProjectSteps(ScenarioContext context) {
//        scenarioContext = context;
//    }
//
//
//
//    @When("Add book to your collection")
//    public void theUserFillsInAllProjectInformation() {
//        scenarioContext.setContext("project", project);
//
//        createProjectPage.inputName(TXT_NAMEDEMO);
//        createProjectPage.inputLastDemo(TXT_LASTNAMEDEMO);
//        createProjectPage.inputEmailDemo(SignInConstant.TXT_EMAILDEMO);
//        createProjectPage.clickGenderRDO();
//        createProjectPage.inputProjectMobileDemo(SignInConstant.TXT_MOBILEDEMO);
//        createProjectPage.clickSelectProjectDOBBtn();
//        createProjectPage.inputProjectDOB(SignInConstant.INP_DOB);
//        createProjectPage.inputSubjectsDemo(SignInConstant.TXT_SUBJECTS);
//        createProjectPage.clickSelectHobbiesProjectCheckbox();
//        createProjectPage.inputCurrentAddressDemo(SignInConstant.TXT_CURRENTADDRESS);
//        createProjectPage.clickSelectStateProjectBtn();
//        createProjectPage.inputStateProjectBtn2();
//        createProjectPage.clickSelectSectorProjectBtn();
//        createProjectPage.inputCityProjectBtn2();
//    }
//
//    @When("the user click Create button")
//    public void theUserClickCreateButton() {
//        createProjectPage.clickCreateSubmitProjectBtn();
//    }
//}