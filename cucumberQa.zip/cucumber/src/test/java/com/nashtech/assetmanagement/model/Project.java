package com.nashtech.assetmanagement.model;
import com.google.gson.JsonObject;

public class Project {
        public String projectName;
        public String projectType;
        public String projectStatus;
        public String startDate;
        public String endDate;
        public String sizeDays;
        public String location;
        public String projectManager;
        public String deliveryProgramManager;
        public String engagementManager;
        public String shortDescription;
        public String longDescription;
        public String technologies;
        public String clientName;
        public String clientDescription;
        public String clientIndustrySector;



        public Project(String projectName, String projectType, String location) {
            this.projectName = projectName;
            this.projectType = projectType;
            this.location = location;
        }
    }


