//package com.nashtech.assetmanagement.steps;
//
//public class login {
//    @Given("")
//    public void TheUserPage(){
//
//    }
//
//    @When("")
//    public void TheUserInputUsernamePage(String arg){
//
//    }
//
//    @And("")
//    public void TheUserInputPasswordPage(){
//
//    }
//    @And("")
//    public void TheUserInputPasswordPage(){
//
//    }
//    @Then("")
//    public void TheUserInputPasswordPage(){
//
//    }
//
//}
