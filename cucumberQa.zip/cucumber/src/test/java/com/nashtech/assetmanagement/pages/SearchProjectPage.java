package com.nashtech.assetmanagement.pages;

import com.nashtech.assetmanagement.model.Project;
import com.nashtech.assetmanagement.steps.StepHooks;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class SearchProjectPage extends BasePage{
    private static final By TXT_PROJECT_NAME = By.cssSelector("input[ng-model='input.projectname']");
    private static final By DDL_LOCATION = By.id("ddl-location");
    private static final String LBL_LOCATION_OPTION = "#ddl-location > option[value='%s']";
    private static final By DDL_PROJECT_TYPE = By.id("ddl-projecttype");
    private static final String LBL_PROJECT_TYPE_OPTION = "#ddl-projecttype > option[value='%s']";
    private static final By BTN_SEARCH = By.cssSelector("#searchProject button[class*=glyphicon-search]");

    /** Search result */
    private static final By LNK_NEXT_PAGE = By.xpath("//a[text()='›']");
    private static final By LNK_NEXT_PAGE_PARENT = By.xpath("//a[text()='›']/..");
    private static final By DBL_RESULT_ITEM = By.cssSelector("div[ui-view='projectsresult'] tbody tr");
    private static final By LBL_PROJECT_NAME_RESULT = By.cssSelector("div[ui-view='projectsresult'] tr td:nth-child(1)");
    private static final By LBL_LOCATION_RESULT = By.cssSelector("div[ui-view='projectsresult'] tr td:nth-child(6)");
    private static final By LBL_PROJECT_TYPE_RESULT = By.cssSelector("div[ui-view='projectsresult'] tr td:nth-child(3)");
    private static final String LNK_PROJECT_NAME = "//a[text()='%s']";

    public void inputProjectName(String projectName) {
        inputText(TXT_PROJECT_NAME, projectName);
    }
    public void selectLocationLbl(String location) {
        selectElementInDropdownList(DDL_LOCATION, By.cssSelector(String.format(LBL_LOCATION_OPTION, location)));
    }
    public void selectProjectTypeLbl(String projectType) {
        selectElementInDropdownList(DDL_PROJECT_TYPE, By.cssSelector(String.format(LBL_PROJECT_TYPE_OPTION, projectType)));
    }
    public void clickSearchBtn() {
        clickElement(BTN_SEARCH);
    }

    public List<Project> getProjectListFromWebElementList(List<WebElement> elementList) {
        List<Project> projectList = new ArrayList<>();
        String projectName;
        String projectType;
        String location;

        for (WebElement element : elementList) {
            projectName = element.findElement(LBL_PROJECT_NAME_RESULT).getText();
            projectType = element.findElement(LBL_PROJECT_TYPE_RESULT).getText();
            location = element.findElement(LBL_LOCATION_RESULT).getText();
            projectList.add(new Project(projectName, projectType, location));
        }

        return projectList;
    }
    public List<Project> getResultProjectListInCurrentPage() {
        waitForElementToBeVisible(DBL_RESULT_ITEM);
        List<Project> projectList = new ArrayList<>();

        try {
            List<WebElement> elementList = StepHooks.driver.findElements(DBL_RESULT_ITEM);
            projectList = getProjectListFromWebElementList(elementList);
        } catch (StaleElementReferenceException e) {
            projectList.removeAll(projectList);
            List<WebElement> elementList = StepHooks.driver.findElements(DBL_RESULT_ITEM);
            projectList = getProjectListFromWebElementList(elementList);
        }

        return projectList;
    }
    public List<Project> getResultProjectListInAllPages() {
        List<Project> projectList = getResultProjectListInCurrentPage();

        while (!isElementContainClass(LNK_NEXT_PAGE_PARENT, "disabled")) {
            clickElement(LNK_NEXT_PAGE);
            projectList.addAll(getResultProjectListInCurrentPage());
        }

        return projectList;
    }
    public void searchProject(String projectName) {
        inputProjectName(projectName);
        clickSearchBtn();
    }
    public void selectProject(String projectName) {
        clickElement(By.xpath(String.format(LNK_PROJECT_NAME, projectName)));
    }
    public boolean isProjectVisible(String projectName) {
        return isElementDisplayed(By.xpath(String.format(LNK_PROJECT_NAME, projectName)));
    }
}