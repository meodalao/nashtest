package com.nashtech.assetmanagement.steps;

import com.nashtech.assetmanagement.constants.FILECONSTANT;
import com.nashtech.assetmanagement.CONTEXT.ScenarioContext;
import com.nashtech.assetmanagement.model.Project;
import com.nashtech.assetmanagement.pages.*;
import com.nashtech.assetmanagement.pages.shared.DatePicker;
import com.nashtech.assetmanagement.pages.shared.ModalDialog;
import com.nashtech.assetmanagement.utils.JsonUtil;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

import java.io.IOException;

public class CreateProjectSteps {
    NavigationPage navigationPage = new NavigationPage();
    CreateProjectPage createProjectPage = new CreateProjectPage();
    DatePicker datePicker = new DatePicker();
    SearchProjectPage searchProjectPage = new SearchProjectPage();
    ProjectInformationPage projectInformationPage = new ProjectInformationPage();
    ModalDialog modalDialog = new ModalDialog();
    Project project;
    ScenarioContext scenarioContext;

    public CreateProjectSteps(ScenarioContext context) {
        scenarioContext = context;
    }

    @And("there is no project have same name with new project")
    public void thereIsNoProjectHaveSameNameWithNewProject() throws IOException {
        project = JsonUtil.loadProjectObject(System.getProperty("TEST_DATA_PATH") + FILECONSTANT.PROJECT_DATA);
        navigationPage.clickSearchProjectLbl();
        searchProjectPage.searchProject(project.projectName);
        if (searchProjectPage.isProjectVisible(project.projectName)) {
            searchProjectPage.selectProject(project.projectName);
            projectInformationPage.clickDeleteBtn();
            modalDialog.clickConfirmDeleteBtn();
            modalDialog.clickCloseDeleteSuccessfullyNotificationMessageBtn();
        }
    }

    @When("the user fills in all project information")
    public void theUserFillsInAllProjectInformation() {
        scenarioContext.setContext("project", project);

        createProjectPage.inputProjectName(project.projectName);
        createProjectPage.selectProjectTypeLbl(project.projectType);
        createProjectPage.selectProjectStatusLbl(project.projectStatus);
        createProjectPage.clickStartDateDtp();
        datePicker.selectDateInCalender(project.startDate);
        createProjectPage.clickEndDateDtp();
        datePicker.selectDateInCalender(project.endDate);
        createProjectPage.inputSizeDays(project.sizeDays);
        createProjectPage.selectLocationLbl(project.location);
        createProjectPage.selectProjectManagerLbl(project.projectManager);
        createProjectPage.selectDeliveryProgramManagerLbl(project.deliveryProgramManager);
        createProjectPage.selectEngagementManagerLbl(project.engagementManager);

        createProjectPage.inputShortDescription(project.shortDescription);
        createProjectPage.inputLongDescription(project.longDescription);
        createProjectPage.inputTechnologies(project.technologies);
        createProjectPage.inputClientName(project.clientName);
        createProjectPage.selectClientIndustrySectorLbl(project.clientIndustrySector);
        createProjectPage.inputClientDescription(project.clientDescription);
    }

    @When("the user click Create button")
    public void theUserClickCreateButton() {
        createProjectPage.clickCreateBtn();
    }
}