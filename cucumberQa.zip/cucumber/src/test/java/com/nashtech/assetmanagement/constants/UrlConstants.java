package com.nashtech.assetmanagement.constants;

public class UrlConstants {
    public static final String LOGIN = "/login";
}
