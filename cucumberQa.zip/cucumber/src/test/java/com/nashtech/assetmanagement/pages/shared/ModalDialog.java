package com.nashtech.assetmanagement.pages.shared;
import com.nashtech.assetmanagement.pages.BasePage;
import org.openqa.selenium.By;

public class ModalDialog extends BasePage {
    private static final By BTN_CONFIRM_DELETE = By.cssSelector("button[ng-click*='deleteProject']");
    private static final By BTN_CLOSE_DELETE_SUCCESSFULLY_NOTIFICATION_MESSAGE = By.xpath("//button[text()='×']");

    public void clickConfirmDeleteBtn() {
        clickElement(BTN_CONFIRM_DELETE);
    }

    public void clickCloseDeleteSuccessfullyNotificationMessageBtn() {
        clickElement(BTN_CLOSE_DELETE_SUCCESSFULLY_NOTIFICATION_MESSAGE);
    }
}
