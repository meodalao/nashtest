//package com.nashtech.assetmanagement.tests;
//
//import org.testng.annotations.DataProvider;
//
//@CucumberOptions(
//        feautures = {"src/test/resources/features/"}
//        glue = {"com/nashtech/demoqa/steps"}
//)
//public class cucumber {
//    @Override
//    @DataProvider()
//    public Object[][] scenarios(){
//        return super.scenarios();
//    }
//}
