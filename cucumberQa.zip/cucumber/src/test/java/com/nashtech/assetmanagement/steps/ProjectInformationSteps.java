package com.nashtech.assetmanagement.steps;

import com.nashtech.assetmanagement.CONTEXT.ScenarioContext;
import com.nashtech.assetmanagement.model.Project;
import com.nashtech.assetmanagement.pages.ProjectInformationPage;
import io.cucumber.java.en.Then;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class ProjectInformationSteps {
    ProjectInformationPage projectInformationPage = new ProjectInformationPage();
    ScenarioContext scenarioContext;
    public ProjectInformationSteps(ScenarioContext context) {
        scenarioContext = context;
    }
    @Then("all information of the project is shown")
    public void allInformationOfTheProjectIsShown() {
        Project project = scenarioContext.getContext("project", Project.class);

        assertThat("Verify project name", projectInformationPage.getProjectName(), equalTo(project.projectName));
        assertThat("Verify project type", projectInformationPage.getProjectType(), equalTo(project.projectType));
        assertThat("Verify project status", projectInformationPage.getProjectStatus(), equalTo(project.projectStatus));

        assertThat("Verify start date", projectInformationPage.getStartDate(), equalTo(project.startDate));
        assertThat("Verify end date", projectInformationPage.getEndDate(), equalTo(project.endDate));

        assertThat("Verify size (days)", projectInformationPage.getSizeDays(), equalTo(project.sizeDays));
        assertThat("Verify location", projectInformationPage.getLocation(), equalTo(project.location));

        assertThat("Verify project manager", projectInformationPage.getProjectManager(), equalTo(removeNickName(project.projectManager)));
        assertThat("Verify delivery/program manager", projectInformationPage.getDeliveryProgramManager(), equalTo(removeNickName(project.deliveryProgramManager)));
        assertThat("Verify engagement manager", projectInformationPage.getEngagementManager(), equalTo(removeNickName(project.engagementManager)));

        assertThat("Verify short description", projectInformationPage.getShortDescription(), equalTo(project.shortDescription));
        assertThat("Verify long description", projectInformationPage.getLongDescription(), equalTo(project.longDescription));
        assertThat("Verify technologies", projectInformationPage.getTechnologies(), equalTo(project.technologies));
        assertThat("Verify client name", projectInformationPage.getClientName(), equalTo(project.clientName));
        assertThat("Verify client industry/sector", projectInformationPage.getClientIndustrySector(), equalTo(project.clientIndustrySector));
        assertThat("Verify client description", projectInformationPage.getClientDescription(), equalTo(project.clientDescription));
    }

    public String removeNickName(String currentString) {
        return currentString.substring(0, currentString.indexOf("(") - 1);
    }
}