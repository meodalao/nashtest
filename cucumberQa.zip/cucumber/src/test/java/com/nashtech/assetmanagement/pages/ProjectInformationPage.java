package com.nashtech.assetmanagement.pages;

import org.openqa.selenium.By;

public class ProjectInformationPage extends BasePage {
    private static final By LBL_PROJECT_NAME = By.xpath(createLocator("Project Name"));
    private static final By LBL_PROJECT_TYPE = By.xpath(createLocator("Project Type"));
    private static final By LBL_PROJECT_STATUS = By.xpath(createLocator("Project Status"));
    private static final By LBL_START_DATE = By.xpath(createLocator("Start Date"));
    private static final By LBL_END_DATE = By.xpath(createLocator("End Date"));
    private static final By LBL_SIZE_DAYS = By.xpath(createLocator("Size (days)"));
    private static final By LBL_LOCATION = By.xpath(createLocator("Location"));
    private static final By LBL_PROJECT_MANAGER = By.xpath(createLocator("Project Manager"));
    private static final By LBL_DELIVERY_PROGRAM_MANAGER = By.xpath(createLocator("Delivery / Program Manager"));
    private static final By LBL_ENGAGEMENT_MANAGER = By.xpath(createLocator("Engagement Manager"));
    private static final By LBL_SHORT_DESCRIPTION = By.xpath(createLocator("Short Description"));
    private static final By LBL_LONG_DESCRIPTION = By.xpath(createLocator("Long Description"));
    private static final By LBL_TECHNOLOGIES = By.xpath(createLocator("Technologies"));
    private static final By LBL_CLIENT_NAME = By.xpath(createLocator("Client Name"));
    private static final By LBL_CLIENT_INDUSTRY_SECTOR = By.xpath(createLocator("Client Industry / Sector"));
    private static final By LBL_CLIENT_DESCRIPTION = By.xpath(createLocator("Client Description"));
    private static final By BTN_DELETE = By.xpath("//button[text()='Delete']");

    public String getProjectName() {
        return getText(LBL_PROJECT_NAME);
    }

    public String getProjectType() {
        return getText(LBL_PROJECT_TYPE);
    }

    public String getProjectStatus() {
        return getText(LBL_PROJECT_STATUS);
    }

    public String getStartDate() {
        return getText(LBL_START_DATE);
    }

    public String getEndDate() {
        return getText(LBL_END_DATE);
    }

    public String getSizeDays() {
        return getText(LBL_SIZE_DAYS);
    }

    public String getLocation() {
        return getText(LBL_LOCATION);
    }

    public String getProjectManager() {
        return getText(LBL_PROJECT_MANAGER);
    }

    public String getDeliveryProgramManager() {
        return getText(LBL_DELIVERY_PROGRAM_MANAGER);
    }

    public String getEngagementManager() {
        return getText(LBL_ENGAGEMENT_MANAGER);
    }

    public String getShortDescription() {
        return getText(LBL_SHORT_DESCRIPTION);
    }

    public String getLongDescription() {
        return getText(LBL_LONG_DESCRIPTION);
    }

    public String getTechnologies() {
        return getText(LBL_TECHNOLOGIES);
    }

    public String getClientName() {
        return getText(LBL_CLIENT_NAME);
    }

    public String getClientIndustrySector() {
        return getText(LBL_CLIENT_INDUSTRY_SECTOR);
    }

    public String getClientDescription() {
        return getText(LBL_CLIENT_DESCRIPTION);
    }

    public void clickDeleteBtn() {
        clickElement(BTN_DELETE);
    }

    public static String createLocator(String specific) {
        return String.format("//label[text()='%s : ']/following-sibling::p", specific);
    }
}
