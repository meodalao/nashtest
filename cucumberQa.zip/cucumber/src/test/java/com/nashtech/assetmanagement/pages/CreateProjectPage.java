package com.nashtech.assetmanagement.pages;

import org.openqa.selenium.By;

public class CreateProjectPage extends BasePage {

    private static final By TXT_PROJECT_NAME = By.id("name");
    private static final By DDL_PROJECT_TYPE = By.id("projecttype");
    private static final By DDL_PROJECT_STATUS = By.id("status");
    private static final String LBL_TYPE_STATUS_INDUSTRY_OPTION = "//option[@label='%s']";
    private static final By DTP_START_DATE = By.name("sdate");
    private static final By DTP_END_DATE = By.name("edate");
    private static final By TXT_SIZE_DAYS = By.id("sizeday");
    private static final By DDL_LOCATION = By.cssSelector("select[ng-options*='location']");
    private static final String LBL_LOCATION_OPTION = "//select[@id='location']/option[@label='%s']";
    private static final By DDL_PROJECT_MANAGER = By.cssSelector("select[ng-options*='projectManager']");
    private static final String LBL_PROJECT_MANAGER_OPTION = "//select[@id='projectManager']/option[@label='%s']";
    private static final By DDL_DELIVERY_PROGRAM_MANAGER = By.cssSelector("select[ng-options*='deliveryManager']");
    private static final String LBL_DELIVERY_PROGRAM_MANAGER_OPTION = "//select[@id='deliveryManager']/option[@label='%s']";
    private static final By DDL_ENGAGEMENT_MANAGER = By.cssSelector("select[ng-options*='engagementManager']");
    private static final String LBL_ENGAGEMENT_MANAGER_OPTION = "//select[@id='engagementManager']/option[@label='%s']";
    private static final By TXA_SHORT_DESCRIPTION = By.id("shortDescription");
    private static final By TXA_LONG_DESCRIPTION = By.id("longDescription");
    private static final By TXA_TECHNOLOGIES = By.cssSelector("textarea[name=technologies]");
    private static final By TXT_CLIENT_NAME = By.cssSelector("input[name=clientName]");
    private static final By DDL_CLIENT_INDUSTRY_SECTOR = By.id("clientindustry");
    private static final By TXA_CLIENT_DESCRIPTION = By.id("clientdescription");
    private static final By BTN_CREATE = By.id("btnConfirm");

    public void inputProjectName(String projectName) {
        inputText(TXT_PROJECT_NAME, projectName);
    }

    public void inputSizeDays(String sizeDays) {
        inputText(TXT_SIZE_DAYS, sizeDays);
    }

    public void inputShortDescription(String shortDescription) {
        inputText(TXA_SHORT_DESCRIPTION, shortDescription);
    }

    public void inputLongDescription(String longDescription) {
        inputText(TXA_LONG_DESCRIPTION, longDescription);
    }

    public void inputTechnologies(String projectType) {
        inputText(TXA_TECHNOLOGIES, projectType);
    }

    public void inputClientName(String clientName) {
        inputText(TXT_CLIENT_NAME, clientName);
    }

    public void inputClientDescription(String clientDescription) {
        inputText(TXA_CLIENT_DESCRIPTION, clientDescription);
    }

    public void clickStartDateDtp() {
        clickElement(DTP_START_DATE);
    }

    public void clickEndDateDtp() {
        clickElement(DTP_END_DATE);
    }

    public void clickCreateBtn() {
        clickElement(BTN_CREATE);
    }

    public void selectProjectTypeLbl(String projectType) {
        selectElementInDropdownList(DDL_PROJECT_TYPE, By.xpath(String.format(LBL_TYPE_STATUS_INDUSTRY_OPTION, projectType)));
    }

    public void selectProjectStatusLbl(String projectStatus) {
        selectElementInDropdownList(DDL_PROJECT_STATUS, By.xpath(String.format(LBL_TYPE_STATUS_INDUSTRY_OPTION, projectStatus)));
    }

    public void selectLocationLbl(String location) {
        selectElementInDropdownList(DDL_LOCATION, By.xpath(String.format(LBL_LOCATION_OPTION, location)));
    }

    public void selectProjectManagerLbl(String projectManager) {
        selectElementInDropdownList(DDL_PROJECT_MANAGER, By.xpath(String.format(LBL_PROJECT_MANAGER_OPTION, projectManager)));
    }

    public void selectDeliveryProgramManagerLbl(String deliveryManager) {
        selectElementInDropdownList(DDL_DELIVERY_PROGRAM_MANAGER, By.xpath(String.format(LBL_DELIVERY_PROGRAM_MANAGER_OPTION, deliveryManager)));
    }

    public void selectEngagementManagerLbl(String engagementManager) {
        selectElementInDropdownList(DDL_ENGAGEMENT_MANAGER, By.xpath(String.format(LBL_ENGAGEMENT_MANAGER_OPTION, engagementManager)));
    }

    public void selectClientIndustrySectorLbl(String industry) {
        selectElementInDropdownList(DDL_CLIENT_INDUSTRY_SECTOR, By.xpath(String.format(LBL_TYPE_STATUS_INDUSTRY_OPTION, industry)));
    }
}

