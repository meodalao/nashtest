package com.nashtech.assetmanagement.utils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.nashtech.assetmanagement.model.Project;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;

public class JsonUtil {
    public static Project loadProjectObject(String filePath) throws IOException {
        try (Reader reader = Files.newBufferedReader(Paths.get(filePath))) {
            Gson gson = new Gson();
            return gson.fromJson(reader, Project.class);
        }
    }
}
